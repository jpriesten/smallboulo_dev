<?php $__env->startSection('content'); ?>
    
    <link rel="stylesheet" type="text/css" href="/css/empPages.css">
    <link rel="stylesheet" type="text/css" href="/css/empGenSearch.css">

    <div class="pageContent">
        <div class="container">
            <div class="row">
                
                <?php echo $__env->make('layouts.workerSideNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                  <!-- dashboard -->
                  <div class="col-md-9">
                    <!-- Write new code here-->

                    <h2>Show catalog of user</h2>

                  </div>
                  <!-- closing of dashboard -->

                 
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.worker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>