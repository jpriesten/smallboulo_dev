<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" type="text/css" href="/css/empPages.css">
    <link rel="stylesheet" type="text/css" href="/css/empGenSearch.css">

    
    <div class="pageContent">
        <div class="container">
            <div class="row">
                
                <?php echo $__env->make('layouts.sideNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                  <!-- dashboard -->
                 <div class="col-md-9">
                 
                    <h2>Employer notification goes here</h2>

                 </div> <!-- closing of dashboard -->

                 
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

	  	

<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>