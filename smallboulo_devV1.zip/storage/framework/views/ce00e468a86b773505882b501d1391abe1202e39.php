	
	<div>
	  <h4><?php echo e($post->userSkill); ?> Needed! <?php echo e($post->user->lastName); ?> on <?php echo e($post->user->created_at->toFormattedDateString()); ?></h4>
	  <p> <?php echo e($post->toDo); ?>.</p>
	  <small>Category of Job: <?php echo e($post->userSkill); ?></small>
	  <hr>
	</div>