
<div class="col-md-3"> 
    <?php if(Auth::check()): ?>
    <!-- left image section --> 
    <img class="img img-reponsive img-thumbnail" src="/pics/sb2.png" alt="employer picture" width="185px" height="200px">
    <h3 id="workerName"> <?php echo e(Auth::user()->firstName); ?> <?php echo e(Auth::user()->lastName); ?>  </h3>
    
    <div class="clearfix"></div>

    <!-- leftmost side links -->
    <ul class="list-unstyled">
        <li><a href="requests" id="whenWorkerActive"> Work Requests </a><li>
        
        <li><a href="catalog" id="workerColor"> Catalog </a></li>

        <li><a href="notification" id="workerColor"> Notifications <span class="badge">15</span></a></li>
    </ul>                       
    <?php endif; ?>
</div>