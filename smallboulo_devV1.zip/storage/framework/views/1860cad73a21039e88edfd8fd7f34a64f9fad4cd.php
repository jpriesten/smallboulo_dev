

<div class="col-md-3"> 
    <?php if(Auth::check()): ?>
    <!-- left image section --> 
    <img class="img img-reponsive img-thumbnail" src="/pics/intro-bg.png" alt="employer picture" width="185px" height="200px">
    <h4 id="employerName"> <?php echo e(Auth::user()->firstName); ?> <?php echo e(Auth::user()->lastName); ?> </h4>
    
    <div class="clearfix"></div>

    <!-- leftmost side links -->
    <ul class="list-unstyled">
        <li><a href="myPosts" id="employerColor"> My Posts </a><li>
        
        <li><a href="postJob" id="employerColor"> Post A Job </a><li>
        
        <li><a href="notifications" id="employerColor"> Notifications <span class="badge">15</span></a></lI>
    </ul>                       
   <?php endif; ?>
</div>