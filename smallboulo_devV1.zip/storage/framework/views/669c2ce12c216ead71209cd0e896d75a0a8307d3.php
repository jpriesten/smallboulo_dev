	
	<div>
	  <h4><?php echo e($searchR->userSkill); ?> Needing! 
			<?php echo e($searchR->user->firstName); ?> <?php echo e($searchR->user->lastName); ?> on 
			<?php echo e($searchR->created_at->toFormattedDateString()); ?>

		</h4>
	  <p><?php echo e($searchR->toDo); ?>.</p>
	  <a href="/searchResult/<?php echo e($searchR->bouloId); ?>"><small>Category of Job</small></a>
	  <hr>
	</div>