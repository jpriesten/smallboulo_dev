<?php $__env->startSection('content'); ?>


    <link rel="stylesheet" type="text/css" href="/css/empPages.css">
    <link rel="stylesheet" type="text/css" href="/css/empGenSearch.css">
    
    <div class="pageContent">
        <div class="container">
            <div class="row">
                
                <?php echo $__env->make('layouts.sideNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                  <!-- dashboard -->
                  <div class="col-md-9">
                      <!-- Write new code here-->
                      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php echo $__env->make('posts.post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                 <!-- closing of dashboard -->

                 
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
	  	

<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>