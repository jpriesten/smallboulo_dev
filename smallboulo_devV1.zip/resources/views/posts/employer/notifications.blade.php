@extends('layouts.employer')


@section('content')

    <link rel="stylesheet" type="text/css" href="/css/empPages.css">
    <link rel="stylesheet" type="text/css" href="/css/empGenSearch.css">

    
    <div class="pageContent">
        <div class="container">
            <div class="row">
                
                @include('layouts.sideNav')

                  <!-- dashboard -->
                 <div class="col-md-9">
                 
                    <h2>Employer notification goes here</h2>

                 </div> <!-- closing of dashboard -->

                 
            </div>
        </div>

    </div>

@endsection

	  	
